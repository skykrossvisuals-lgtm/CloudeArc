import { Router } from "express";

const router = Router();

const NVIDIA_URL = "https://integrate.api.nvidia.com/v1/chat/completions";

const PRIMARY_MODEL = process.env.MODEL_GENERAL ?? "meta/llama-3.3-70b-instruct";
const FAST_MODEL = process.env.MODEL_FAST ?? "meta/llama-3.1-8b-instruct";

const PLAN_TIMEOUT_MS = 20_000;
const CODE_TIMEOUT_MS = 45_000; // code stage needs more time to stream full file content
const MAX_RETRIES = 1;

function cleanJson(text: string): string {
  return text
    .replace(/```json\s*/g, "")
    .replace(/```\s*/g, "")
    .trim();
}

// Escape literal control characters that appear inside JSON string values.
// LLMs often emit raw newlines/tabs within string content instead of \n / \t.
// We walk char-by-char so we only fix inside strings, not structural whitespace.
function fixControlCharsInStrings(text: string): string {
  let out = "";
  let inString = false;
  let escaped = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const code = text.charCodeAt(i);

    if (escaped) {
      out += ch;
      escaped = false;
      continue;
    }

    if (ch === "\\" && inString) {
      out += ch;
      escaped = true;
      continue;
    }

    if (ch === '"') {
      inString = !inString;
      out += ch;
      continue;
    }

    if (inString && code < 0x20) {
      if (ch === "\n") out += "\\n";
      else if (ch === "\r") out += "\\r";
      else if (ch === "\t") out += "\\t";
      else out += `\\u${code.toString(16).padStart(4, "0")}`;
      continue;
    }

    out += ch;
  }

  return out;
}

// LLMs emit various invalid JSON: bad escape sequences (\' \d etc.) and raw control chars.
// Three-pass repair: raw → fix bad escapes → fix control chars → give up.
function parseJson(text: string): any {
  // Pass 1: raw
  try { return JSON.parse(text); } catch { /* continue */ }

  // Pass 2: fix invalid escape sequences (\' \d etc.)
  const noEscapes = text.replace(/\\([^"\\/bfnrtu\r\n])/g, (_, c: string) => c);
  try { return JSON.parse(noEscapes); } catch { /* continue */ }

  // Pass 3: fix literal control chars inside string values, then re-apply escape fix
  const fixed = fixControlCharsInStrings(text).replace(/\\([^"\\/bfnrtu\r\n])/g, (_, c: string) => c);
  return JSON.parse(fixed);
}

// Parse the delimiter-based coder output format:
//   ===FILE: /path/to/file===
//   ...file content...
// This avoids all JSON escaping issues with code content.
function parseDelimitedFiles(text: string): Array<{ type: string; path: string; content: string }> {
  const results: Array<{ type: string; path: string; content: string }> = [];
  const sections = text.split(/^===FILE:\s*/m);

  for (const section of sections) {
    if (!section.trim()) continue;
    const newlineIdx = section.indexOf("\n");
    if (newlineIdx === -1) continue;
    const path = section.slice(0, newlineIdx).replace(/={0,3}\s*$/, "").trim();
    const content = section.slice(newlineIdx + 1).trimEnd();
    // Reject path traversal and non-absolute paths
    if (path.startsWith("/") && !path.includes("..") && content.length > 0) {
      results.push({ type: "write_file", path, content });
    }
  }

  return results;
}

async function callModelOnce(
  modelName: string,
  system: string,
  prompt: string,
  apiKey: string,
  timeoutMs: number,
  maxTokens = 4096,
): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(NVIDIA_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: modelName,
        temperature: 0.2,
        max_tokens: maxTokens,
        messages: [
          { role: "system", content: system },
          { role: "user", content: prompt },
        ],
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`HTTP ${res.status}: ${body.slice(0, 200)}`);
    }

    const data = await res.json() as { choices?: Array<{ message?: { content?: string } }> };
    return data.choices?.[0]?.message?.content ?? "";
  } finally {
    clearTimeout(timer);
  }
}

async function callModel(
  system: string,
  prompt: string,
  apiKey: string,
  logger: any,
  stage: string,
  timeoutMs = PLAN_TIMEOUT_MS,
  maxTokens = 4096,
): Promise<string> {
  const models = [PRIMARY_MODEL, FAST_MODEL].filter(Boolean);

  for (const model of models) {
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      try {
        logger.info({ stage, model, attempt }, "LLM request");
        const result = await callModelOnce(model, system, prompt, apiKey, timeoutMs, maxTokens);
        logger.info({ stage, model, attempt, chars: result.length }, "LLM ok");
        return result;
      } catch (err: any) {
        const isTimeout = err.name === "AbortError" || err.message?.includes("abort");
        logger.warn({ stage, model, attempt, err: err.message, isTimeout }, "LLM failed");

        const hasRetry = attempt < MAX_RETRIES;
        const hasFallback = model !== models[models.length - 1];

        if (!hasRetry && !hasFallback) throw err;
        if (!hasRetry) break; // move to next model
      }
    }
  }

  throw new Error(`All models failed for stage: ${stage}`);
}

router.post("/", async (req, res) => {
  const startMs = Date.now();
  const apiKey = process.env.NVIDIA_API_KEY;

  if (!apiKey) {
    res.status(500).json([{ type: "console_log", message: "NVIDIA_API_KEY not set" }]);
    return;
  }

  const { prompt } = req.body;

  if (!prompt || typeof prompt !== "string") {
    res.status(400).json([{ type: "console_log", message: "Missing prompt" }]);
    return;
  }

  const log = req.log;

  // Stage 1: Plan
  let steps: string[];
  try {
    const planRaw = await callModel(
      `You are a planning agent. Break the user request into 2-4 concrete implementation steps.
Return ONLY valid JSON: { "steps": ["step 1", "step 2"] }
No markdown, no explanation.`,
      prompt,
      apiKey,
      log,
      "plan",
    );
    steps = parseJson(cleanJson(planRaw)).steps ?? [];
  } catch (err: any) {
    log.error({ err: err.message }, "Plan stage failed");
    res.status(500).json([{ type: "console_log", message: `Planning failed: ${err.message}` }]);
    return;
  }

  // Stage 2: Architect
  let files: string[];
  try {
    const archRaw = await callModel(
      `You are an architecture agent. Given implementation steps, list the exact file paths to create or modify.
Return ONLY valid JSON: { "files": ["/index.html", "/src/App.jsx"] }
Use simple file paths. No markdown, no explanation.`,
      JSON.stringify({ steps, userRequest: prompt }),
      apiKey,
      log,
      "architect",
    );
    files = parseJson(cleanJson(archRaw)).files ?? [];
    if (!files.length) throw new Error("No files returned");
  } catch (err: any) {
    log.error({ err: err.message }, "Architect stage failed");
    files = ["/index.html"];
  }

  // Stage 3: Code — delimiter format avoids all JSON escaping issues with code content
  let actions: any[] = [];
  try {
    const codeRaw = await callModel(
      `You are a coding agent. Write complete file contents for every file listed.

Output format — use EXACTLY this structure for each file:
===FILE: /path/to/file===
(complete file content here, no truncation)

Files to write: ${files.join(", ")}

Rules:
- Write every file listed above
- Complete, working code — no placeholders, no TODO, no truncation
- Separate each file with ===FILE: /path=== on its own line
- Do not add any explanation, preamble, or text outside the file blocks`,
      prompt,
      apiKey,
      log,
      "code",
      CODE_TIMEOUT_MS,
      8192,
    );

    // Try delimiter format first (preferred, no JSON escaping issues).
    // If the model ignored the format and returned JSON (common with the fast
    // fallback model), parse that too so we never hard-fail on format mismatch.
    actions = parseDelimitedFiles(codeRaw);
    if (actions.length > 0) {
      log.info({ fileCount: actions.length, format: "delimiter", paths: actions.map((a: any) => a.path) }, "Parsed coder output");
    } else {
      log.warn({}, "Delimiter parse returned 0 files — attempting JSON fallback");
      try {
        const parsed = parseJson(cleanJson(codeRaw));
        const arr: any[] = Array.isArray(parsed) ? parsed : [];
        actions = arr.filter(
          (a) => a.type === "write_file" && typeof a.path === "string" && typeof a.content === "string",
        );
        log.info({ fileCount: actions.length, format: "json-fallback" }, "JSON fallback parsed");
      } catch (jsonErr: any) {
        log.warn({ err: jsonErr.message }, "JSON fallback also failed — empty action list");
      }
    }
  } catch (err: any) {
    log.error({ err: err.message }, "Code stage failed");
    res.status(500).json([{ type: "console_log", message: `Code generation failed: ${err.message}` }]);
    return;
  }

  const safeActions = actions.filter(
    (a: any) =>
      a.type === "write_file" &&
      typeof a.path === "string" &&
      typeof a.content === "string" &&
      a.content.length > 0,
  );

  if (!safeActions.length) {
    log.warn({ rawCount: actions.length }, "No valid write_file actions after filtering");
    res.status(500).json([{ type: "console_log", message: "No valid file actions generated. Try rephrasing." }]);
    return;
  }

  log.info({
    duration_ms: Date.now() - startMs,
    file_count: safeActions.length,
  }, "Generation complete");
  res.json(safeActions);
});

export default router;
