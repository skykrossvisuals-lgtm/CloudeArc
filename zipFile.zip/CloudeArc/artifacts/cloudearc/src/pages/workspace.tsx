import Editor from "@monaco-editor/react";
import { useEffect, useState, useRef, useCallback } from "react";
import debounce from "lodash/debounce";
import { bootSandbox, getPreviewUrl, writeFile, deleteFile } from "../lib/sandbox";

let sandboxBootPromise: Promise<void> | null = null;

// ─── helpers ────────────────────────────────────────────────────────────────

let _id = 0;
const uid = () => ++_id;

function describePrompt(p: string): string {
  const s = p.toLowerCase();
  if (s.includes("landing")) return "landing page";
  if (s.includes("dashboard")) return "dashboard";
  if (s.includes("portfolio")) return "portfolio";
  if (s.includes("blog")) return "blog";
  if (s.includes("login") || s.includes("auth")) return "auth flow";
  if (s.includes("form")) return "form";
  if (s.includes("calculator")) return "calculator";
  if (s.includes("todo") || s.includes("to-do") || s.includes("task")) return "task manager";
  if (s.includes("chat")) return "chat UI";
  if (s.includes("weather")) return "weather app";
  if (s.includes("shop") || s.includes("store") || s.includes("product")) return "storefront";
  if (s.includes("game")) return "game";
  return "app";
}

function fileLabel(path: string): string {
  if (path.endsWith(".tsx") || path.endsWith(".jsx")) return "React component";
  if (path.endsWith(".ts") || path.endsWith(".js")) return "script";
  if (path.endsWith(".css")) return "stylesheet";
  if (path.endsWith(".html")) return "page";
  if (path.endsWith(".json")) return "config";
  return "file";
}

function shortPath(path: string): string {
  return path.replace(/^\//, "").split("/").slice(-2).join("/");
}

// ─── feed types ─────────────────────────────────────────────────────────────

type StepState = "running" | "done" | "error";

type Step = {
  id: number;
  text: string;
  state: StepState;
};

type TaskCard = {
  kind: "task";
  id: number;
  label: string;
  steps: Step[];
  state: "thinking" | "running" | "done" | "error";
  summary: string;
  collapsed: boolean;
};

type UserBubble = {
  kind: "user";
  id: number;
  content: string;
};

type FeedItem = UserBubble | TaskCard;

// ─── sub-components ─────────────────────────────────────────────────────────

function Spinner({ size = 14, dim = false }: { size?: number; dim?: boolean }) {
  return (
    <span
      style={{ width: size, height: size }}
      className={`inline-block shrink-0 rounded-full border-2 animate-spin
        ${dim
          ? "border-zinc-700 border-t-zinc-400"
          : "border-zinc-600 border-t-zinc-200"
        }`}
    />
  );
}

function StepRow({ step }: { step: Step }) {
  return (
    <div className="flex items-start gap-2 text-xs py-0.5">
      <span className="mt-0.5 shrink-0 w-3.5">
        {step.state === "running" && <Spinner size={12} dim />}
        {step.state === "done" && <span className="text-zinc-500 text-[11px]">✓</span>}
        {step.state === "error" && <span className="text-red-500 text-[11px]">✗</span>}
      </span>
      <span className={
        step.state === "running" ? "text-zinc-300" :
        step.state === "done" ? "text-zinc-600" :
        "text-red-400"
      }>
        {step.text}
      </span>
    </div>
  );
}

function TaskCardView({
  task,
  onToggle,
}: {
  task: TaskCard;
  onToggle: (id: number) => void;
}) {
  const canCollapse = task.state === "done" || task.state === "error";
  const showSteps = !task.collapsed && task.steps.length > 0;

  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.03] overflow-hidden">
      {/* header */}
      <button
        className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left"
        onClick={() => canCollapse && onToggle(task.id)}
      >
        <span className="shrink-0">
          {task.state === "thinking" && <Spinner size={13} />}
          {task.state === "running" && <Spinner size={13} />}
          {task.state === "done" && (
            <span className="inline-flex w-[13px] h-[13px] items-center justify-center rounded-full bg-white/10">
              <span className="text-[9px] text-zinc-300">✓</span>
            </span>
          )}
          {task.state === "error" && (
            <span className="inline-flex w-[13px] h-[13px] items-center justify-center rounded-full bg-red-500/20">
              <span className="text-[9px] text-red-400">✗</span>
            </span>
          )}
        </span>

        <span className={`flex-1 text-sm font-medium leading-snug ${
          task.state === "done" ? "text-zinc-400" : "text-zinc-200"
        }`}>
          {task.label}
        </span>

        {canCollapse && (
          <span className="text-zinc-600 text-xs ml-1">
            {task.collapsed ? "▸" : "▾"}
          </span>
        )}
      </button>

      {/* steps */}
      {showSteps && (
        <div className="px-3 pb-2.5 border-t border-white/[0.05] pt-2 space-y-0.5">
          {task.steps.map((s) => <StepRow key={s.id} step={s} />)}
        </div>
      )}

      {/* summary */}
      {task.summary && !task.collapsed && (
        <div className={`px-3 pb-3 text-xs leading-relaxed ${
          task.state === "error" ? "text-red-400" : "text-zinc-500"
        }`}>
          {task.summary}
        </div>
      )}
    </div>
  );
}

// ─── main component ─────────────────────────────────────────────────────────

export default function WorkspacePage({ params }: { params: { id: string } }) {
  const projectId = params.id;
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const [files, setFiles] = useState<Record<string, string>>({
    "/index.html": `<!DOCTYPE html>\n<html>\n  <body>\n    <h1>Ready</h1>\n  </body>\n</html>`,
  });
  const [ready, setReady] = useState(false);
  const [url, setUrl] = useState("");
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [prompt, setPrompt] = useState<string | null>(null);
  const [feed, setFeed] = useState<FeedItem[]>([]);
  const [tab, setTab] = useState<"preview" | "code" | "logs">("preview");
  const [activeFile, setActiveFile] = useState("/index.html");
  const [filePanelOpen, setFilePanelOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const thinkTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  // Monotonically-increasing counter: lets executeActions detect if a newer
  // generation started and bail out early, preventing stale writes.
  const genRef = useRef(0);
  // Stable ref to the latest preview url so debounced callbacks don't close
  // over a stale empty string from the first render.
  const urlRef = useRef("");

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [feed]);

  // Keep urlRef in sync so stable debounce callbacks always see the latest url.
  useEffect(() => { urlRef.current = url; }, [url]);

  const reloadPreview = () => {
    // Append cache-busting timestamp so the browser always fetches fresh content
    // even when the iframe src string hasn't changed.
    if (iframeRef.current && urlRef.current) {
      iframeRef.current.src = urlRef.current + "?t=" + Date.now();
    }
  };

  // ── feed mutations ──────────────────────────────────────────────────────

  const updateTask = useCallback(
    (taskId: number, updater: (t: TaskCard) => TaskCard) => {
      setFeed((prev) =>
        prev.map((item) =>
          item.kind === "task" && item.id === taskId ? updater(item) : item
        )
      );
    },
    []
  );

  const addStep = useCallback(
    (taskId: number, text: string, state: StepState = "running"): number => {
      const stepId = uid();
      updateTask(taskId, (t) => ({
        ...t,
        steps: [...t.steps, { id: stepId, text, state }],
      }));
      return stepId;
    },
    [updateTask]
  );

  const resolveStep = useCallback(
    (taskId: number, stepId: number, state: StepState, newText?: string) => {
      updateTask(taskId, (t) => ({
        ...t,
        steps: t.steps.map((s) =>
          s.id === stepId ? { ...s, state, text: newText ?? s.text } : s
        ),
      }));
    },
    [updateTask]
  );

  const finishTask = useCallback(
    (taskId: number, state: "done" | "error", summary: string) => {
      updateTask(taskId, (t) => ({ ...t, state, summary, collapsed: state === "done" }));
    },
    [updateTask]
  );

  // ── thinking timers ─────────────────────────────────────────────────────

  const stopThinkTimers = () => {
    thinkTimers.current.forEach(clearTimeout);
    thinkTimers.current = [];
  };

  const startThinkingPhase = (taskId: number, userPrompt: string) => {
    const what = describePrompt(userPrompt);

    const s1 = addStep(taskId, "Inspecting workspace...");

    const t1 = setTimeout(() => {
      resolveStep(taskId, s1, "done");
      addStep(taskId, `Generating your ${what}...`);
    }, 4000);

    const t2 = setTimeout(() => {
      updateTask(taskId, (t) => ({
        ...t,
        state: "running",
        steps: t.steps.map((s) =>
          s.state === "running" ? { ...s, text: "Writing code..." } : s
        ),
      }));
    }, 13000);

    const t3 = setTimeout(() => {
      updateTask(taskId, (t) => ({
        ...t,
        steps: t.steps.map((s) =>
          s.state === "running" ? { ...s, text: "Finalizing output..." } : s
        ),
      }));
    }, 28000);

    thinkTimers.current = [t1, t2, t3];
  };

  // ── execute actions ─────────────────────────────────────────────────────

  const executeActions = async (
    actions: any[],
    taskId: number,
    userPrompt: string,
    myGen: number,
  ) => {
    // Bail if a newer generation has already started
    if (genRef.current !== myGen) return;

    const writes = actions.filter((a) => a.type === "write_file");

    // Mark current running step done and start file-write phase
    updateTask(taskId, (t) => ({
      ...t,
      state: "running",
      steps: t.steps.map((s) =>
        s.state === "running" ? { ...s, state: "done" } : s
      ),
    }));

    if (writes.length > 0) {
      addStep(taskId, `Creating ${writes.length} file${writes.length !== 1 ? "s" : ""}...`, "running");
      await new Promise((r) => setTimeout(r, 200));

      // Resolve that umbrella step and go per-file
      updateTask(taskId, (t) => ({
        ...t,
        steps: t.steps.map((s) =>
          s.state === "running" ? { ...s, state: "done" } : s
        ),
      }));
    }

    let written = 0;
    const failed: string[] = [];

    for (const action of actions) {
      // Abort mid-batch if superseded by a newer generation
      if (genRef.current !== myGen) return;

      if (action.type === "write_file") {
        const label = `${fileLabel(action.path)}: ${shortPath(action.path)}`;
        const sid = addStep(taskId, label, "running");

        try {
          await writeFile(action.path, action.content);
          setFiles((prev) => ({ ...prev, [action.path]: action.content }));
          setActiveFile(action.path);
          resolveStep(taskId, sid, "done");
          written++;
        } catch (err: any) {
          console.error("[workspace] write failed:", action.path, err);
          resolveStep(taskId, sid, "error", `${label} — failed`);
          failed.push(action.path);
        }

        await new Promise((r) => setTimeout(r, 100));

      } else if (action.type === "delete_file") {
        setFiles((prev) => {
          const c = { ...prev };
          delete c[action.path];
          return c;
        });
        try { await deleteFile(action.path); } catch { /* ignore */ }
      } else if (action.type === "console_log") {
        console.log("[ACOS]", action.message);
      }
    }

    if (written === 0 && failed.length > 0) {
      finishTask(taskId, "error", "All file writes failed. The sandbox may not be ready — try refreshing.");
      return;
    }

    if (genRef.current !== myGen) return;

    const previewSid = addStep(taskId, "Launching preview...", "running");
    reloadPreview();
    await new Promise((r) => setTimeout(r, 600));
    resolveStep(taskId, previewSid, "done");

    const what = describePrompt(userPrompt);
    const failNote = failed.length ? ` (${failed.length} file${failed.length !== 1 ? "s" : ""} failed)` : "";
    const summary =
      written === 1
        ? `Wrote \`${shortPath(writes[0]?.path ?? "")}\`. Your ${what} is live.${failNote}`
        : `Wrote ${written} files. Your ${what} is live in the preview.${failNote}`;

    finishTask(taskId, "done", summary);
  };

  // ── sandbox init ────────────────────────────────────────────────────────

  useEffect(() => {
    const stored = localStorage.getItem("cloudearc-project-" + projectId);
    setPrompt(stored);
  }, [projectId]);

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        setReady(false);
        if (!sandboxBootPromise) sandboxBootPromise = bootSandbox().then(() => {});
        await sandboxBootPromise;
        const preview = await getPreviewUrl();
        if (!alive || !preview) return;
        setUrl(preview);
        setReady(true);
      } catch (err) {
        console.error("SANDBOX FAILED:", err);
        if (!alive) return;
        setReady(false);
      }
    })();

    return () => { alive = false; };
  }, []);

  // debouncedWrite is stable (created once). It reads urlRef at call time so it
  // always gets the latest preview url even though the closure was created on
  // the first render. Cancel on unmount to prevent writes after dismount.
  const debouncedWriteRef = useRef(
    debounce(async (path: string, content: string) => {
      try {
        await writeFile(path, content);
        if (iframeRef.current && urlRef.current) {
          iframeRef.current.src = urlRef.current + "?t=" + Date.now();
        }
      } catch (err) {
        console.error("WRITE FAILED:", err);
      }
    }, 600)
  );
  const debouncedWrite = debouncedWriteRef.current;

  useEffect(() => {
    return () => { debouncedWriteRef.current.cancel(); };
  }, []);

  // ── send ────────────────────────────────────────────────────────────────

  const sendMessage = async () => {
    if (!input.trim() || sending) return;

    const userPrompt = input.trim();
    setInput("");
    setSending(true);
    stopThinkTimers();

    // Cancel any pending Monaco debounce so it can't race with the new generation
    debouncedWrite.cancel();

    // Increment generation counter so any in-flight executeActions from a
    // prior generation will bail when it checks genRef.current.
    const myGen = ++genRef.current;

    const userBubble: UserBubble = { kind: "user", id: uid(), content: userPrompt };

    const taskCard: TaskCard = {
      kind: "task",
      id: uid(),
      label: `Building your ${describePrompt(userPrompt)}...`,
      steps: [],
      state: "thinking",
      summary: "",
      collapsed: false,
    };

    setFeed((prev) => [...prev, userBubble, taskCard]);
    const taskId = taskCard.id;

    startThinkingPhase(taskId, userPrompt);

    try {
      const controller = new AbortController();
      const hardTimeout = setTimeout(() => controller.abort(), 75_000);

      let res: Response;
      try {
        res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt: userPrompt,
            context: { projectId, files: Object.keys(files) },
          }),
          signal: controller.signal,
        });
      } finally {
        clearTimeout(hardTimeout);
      }

      stopThinkTimers();

      const actions = await res.json();

      if (!res.ok || !Array.isArray(actions) || actions.length === 0) {
        const msg = Array.isArray(actions)
          ? actions.find((a: any) => a.type === "console_log")?.message ?? "No actions returned."
          : "Request failed.";
        updateTask(taskId, (t) => ({
          ...t,
          steps: t.steps.map((s) =>
            s.state === "running" ? { ...s, state: "error" } : s
          ),
        }));
        finishTask(taskId, "error", msg);
        return;
      }

      await executeActions(actions, taskId, userPrompt, myGen);

    } catch (err: any) {
      stopThinkTimers();
      const isTimeout = err.name === "AbortError";
      updateTask(taskId, (t) => ({
        ...t,
        steps: t.steps.map((s) =>
          s.state === "running" ? { ...s, state: "error" } : s
        ),
      }));
      finishTask(
        taskId,
        "error",
        isTimeout
          ? "Request timed out. Try a simpler prompt."
          : err.message ?? "Something went wrong."
      );
    } finally {
      setSending(false);
    }
  };

  // ── toggle collapse ─────────────────────────────────────────────────────

  const toggleCollapse = (taskId: number) => {
    updateTask(taskId, (t) => ({ ...t, collapsed: !t.collapsed }));
  };

  // ─────────────────────────────────────────────────────────────────────────
  // render
  // ─────────────────────────────────────────────────────────────────────────

  return (
    <div className="h-screen flex bg-[#0A0A0A] text-white overflow-hidden">
      {/* ICON SIDEBAR */}
      <aside className="w-14 bg-[#0C0C0C] flex flex-col items-center py-3 shrink-0">
        <div className="w-8 h-8 rounded-xl bg-white text-black flex items-center justify-center text-sm font-semibold">
          C
        </div>
        <div className="mt-6 flex flex-col gap-3 text-zinc-500 text-sm">
          <button className="w-9 h-9 rounded-lg bg-white/10 text-white">⌂</button>
          <button className="w-9 h-9 rounded-lg hover:bg-white/5 transition">✦</button>
          <button className="w-9 h-9 rounded-lg hover:bg-white/5 transition">⌘</button>
        </div>
        <div className="mt-auto">
          <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-xs">N</div>
        </div>
      </aside>

      {/* AI PANEL */}
      <aside className="w-80 bg-[#111111] flex flex-col border-r border-white/5 shrink-0">
        <div className="p-4 border-b border-white/5">
          <div className="text-sm font-medium">Build Assistant</div>
          <div className="text-xs text-zinc-500 mt-1">Describe changes to your app</div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {feed.length === 0 && (
            <>
              <div className="bg-white/[0.03] rounded-xl p-3 text-sm text-zinc-300">
                Project initialized successfully.
              </div>
              <div className="bg-white/[0.03] rounded-xl p-3 text-sm text-zinc-300">
                {prompt ? `Prompt: "${prompt}"` : "Waiting for instructions..."}
              </div>
            </>
          )}

          {feed.map((item) =>
            item.kind === "user" ? (
              <div
                key={item.id}
                className="ml-auto w-fit max-w-[88%] bg-white text-black rounded-xl px-3 py-2 text-sm leading-relaxed"
              >
                {item.content}
              </div>
            ) : (
              <TaskCardView
                key={item.id}
                task={item}
                onToggle={toggleCollapse}
              />
            )
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* input */}
        <div className="p-3 border-t border-white/5">
          <div className="bg-white/[0.04] rounded-xl p-3">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={sending ? "Working on it..." : "Ask CloudeArc to build..."}
              disabled={sending}
              className="w-full h-5 bg-transparent resize-none outline-none text-sm placeholder:text-zinc-600 disabled:opacity-40"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
            />
            <div className="flex justify-end mt-3">
              <button
                onClick={sendMessage}
                disabled={!input.trim() || sending}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition
                  ${input.trim() && !sending
                    ? "bg-white text-black hover:scale-105"
                    : "bg-white/10 text-zinc-600 cursor-not-allowed"
                  }`}
              >
                {sending
                  ? <Spinner size={14} />
                  : <span>↑</span>
                }
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN WORKSPACE */}
      <main className="flex-1 flex flex-col bg-[#0B0B0B] relative overflow-hidden">
        {/* TOP BAR */}
        <div className="h-14 border-b border-white/5 flex items-center px-4 shrink-0">
          <div className="flex items-center gap-2 min-w-[180px]">
            <div className="text-sm font-medium">ACOS Workspace</div>
          </div>

          <div className="flex-1 flex justify-center">
            <div className="flex items-center gap-3 bg-white/5 px-3 py-1.5 rounded-lg w-[480px]">
              <span className="text-white opacity-70 shrink-0">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10Z" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M2 12h20" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M12 2c2.5 2.7 4 6.6 4 10s-1.5 7.3-4 10c-2.5-2.7-4-6.6-4-10s1.5-7.3 4-10Z" stroke="currentColor" strokeWidth="1.5" />
                </svg>
              </span>
              <input
                value={url || ""}
                readOnly
                placeholder="Starting preview..."
                className="bg-transparent text-xs text-zinc-300 w-full outline-none"
              />
              <button
                onClick={() => url && window.open(url, "_blank")}
                className="text-xs text-zinc-500 hover:text-white transition whitespace-nowrap"
              >
                Open ↗
              </button>
            </div>
          </div>

          <div className="flex items-center gap-1 ml-auto">
            {(["preview", "code", "logs"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-3 py-1.5 rounded-lg text-xs transition capitalize ${
                  tab === t ? "bg-white/10 text-white" : "text-zinc-500 hover:text-white"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* CONTENT */}
        <div className="flex-1 overflow-hidden relative">
          {tab === "preview" && (
            <div className="w-full h-full flex items-center justify-center">
              {!ready ? (
                <div className="flex flex-col items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl border border-white/10 bg-white/[0.03] flex items-center justify-center animate-pulse">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-white/70">
                      <path d="M12 3V7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                      <path d="M12 17V21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                      <path d="M3 12H7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                      <path d="M17 12H21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </div>
                  <div className="text-sm text-white/70">Initializing Runtime</div>
                  <div className="text-xs text-white/30">Preparing isolated development environment</div>
                </div>
              ) : url ? (
                <iframe ref={iframeRef} src={url} className="w-full h-full border-0" />
              ) : (
                <div className="text-zinc-500 text-sm">Failed to load preview</div>
              )}
            </div>
          )}

          {tab === "code" && (
            <div className="flex h-full bg-[#0F0F0F]">
              <div className="w-60 border-r border-white/5 bg-[#111111] overflow-y-auto shrink-0">
                <div className="p-3 border-b border-white/5 text-xs text-zinc-500 uppercase tracking-wide">Files</div>
                <div className="p-2 space-y-0.5">
                  {Object.keys(files).map((file) => (
                    <button
                      key={file}
                      onClick={() => setActiveFile(file)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition ${
                        activeFile === file
                          ? "bg-white/10 text-white"
                          : "text-zinc-400 hover:bg-white/5 hover:text-white"
                      }`}
                    >
                      {file.replace(/^\//, "")}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex-1 overflow-hidden">
                <Editor
                  height="100%"
                  theme="vs-dark"
                  path={activeFile}
                  defaultLanguage="javascript"
                  value={files[activeFile] || ""}
                  onChange={(value) => {
                    const updated = value || "";
                    setFiles((prev) => ({ ...prev, [activeFile]: updated }));
                    debouncedWrite(activeFile, updated);
                  }}
                  options={{
                    minimap: { enabled: false },
                    fontSize: 14,
                    smoothScrolling: true,
                    automaticLayout: true,
                    padding: { top: 16 },
                    scrollbar: { verticalScrollbarSize: 8, horizontalScrollbarSize: 8 },
                  }}
                />
              </div>
            </div>
          )}

          {tab === "logs" && (
            <div className="p-5 text-zinc-400 text-sm">Logs coming next...</div>
          )}
        </div>

        {/* FILE PANEL OVERLAY */}
        {filePanelOpen && (
          <div className="absolute top-0 right-0 h-full w-72 bg-[#0B0B0B] border-l border-white/10 z-50 flex flex-col">
            <div className="h-12 flex items-center justify-between px-3 border-b border-white/5">
              <div className="text-xs text-white/60">Explorer</div>
              <button
                onClick={() => setFilePanelOpen(false)}
                className="w-7 h-7 flex items-center justify-center hover:bg-white/5 rounded"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path d="M6 6l12 12M18 6L6 18" stroke="white" strokeWidth="1.5" />
                </svg>
              </button>
            </div>
            <div className="p-3 text-xs text-white/60 space-y-2 overflow-y-auto">
              {Object.keys(files).map((file) => (
                <div
                  key={file}
                  onClick={() => setActiveFile(file)}
                  className={`cursor-pointer hover:text-white ${activeFile === file ? "text-white" : ""}`}
                >
                  {file}
                </div>
              ))}
            </div>
          </div>
        )}

        <button onClick={() => setFilePanelOpen(true)} className="absolute top-4 right-4 group z-10">
          <div className="relative w-10 h-10 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-md overflow-hidden transition-all duration-200 hover:bg-white/[0.06] hover:border-white/20">
            <div className="absolute inset-0 bg-gradient-to-b from-white/[0.05] to-transparent opacity-60" />
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" className="text-white/80 group-hover:text-white transition">
                <path d="M4 6.5C4 5.67 4.67 5 5.5 5H9L10.5 7H18.5C19.33 7 20 7.67 20 8.5V17.5C20 18.33 19.33 19 18.5 19H5.5C4.67 19 4 18.33 4 17.5V6.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                <path d="M8 11H16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                <path d="M8 14H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
          </div>
        </button>
      </main>
    </div>
  );
}
